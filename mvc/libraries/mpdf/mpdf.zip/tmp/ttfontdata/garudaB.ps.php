<?php 
$originalsize=55484;
