<?php
$LuCoverage = array (
  0 => 
  array (
    0 => 
    array (
      2497 => 0,
      2498 => 1,
      2499 => 2,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      2492 => 0,
    ),
  ),
);
?>