<?php

$rtlSUB = array();
$finals = '';
$rphf = array (
  2864 => 59426,
);
$half = array (
);
$pref = array (
);
$blwf = array (
);
$pstf = array (
  2863 => 59311,
  2911 => 59310,
);

 
?>