<?php
$name='Kalpurush';
$type='TTF';
$desc=array (
  'CapHeight' => 615,
  'XHeight' => 454,
  'FontBBox' => '[-555 -402 1118 1033]',
  'Flags' => 4,
  'Ascent' => 1000,
  'Descent' => -400,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 672,
);
$unitsPerEm=1000;
$up=-307;
$ut=20;
$strp=250;
$strs=50;
$ttffile='/var/www/html/school3.0/mvc/libraries/mpdf/src/Config/../../ttfonts/kalpurush.ttf';
$TTCfontID='0';
$originalsize=314592;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='kalpurush';
$panose=' 0 0 2 0 6 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1000, -400, 175
// usWinAscent/usWinDescent = 1000, -400
// hhea Ascent/Descent/LineGap = 1000, -400, 175
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'beng' => 'DFLT ',
  'bng2' => 'DFLT ',
);
$GSUBFeatures=array (
  'beng' => 
  array (
    'DFLT' => 
    array (
      'init' => 
      array (
        0 => 0,
      ),
      'nukt' => 
      array (
        0 => 1,
      ),
      'akhn' => 
      array (
        0 => 2,
      ),
      'rphf' => 
      array (
        0 => 3,
      ),
      'blwf' => 
      array (
        0 => 4,
      ),
      'half' => 
      array (
        0 => 6,
      ),
      'pstf' => 
      array (
        0 => 7,
      ),
      'vatu' => 
      array (
        0 => 9,
      ),
      'pres' => 
      array (
        0 => 10,
        1 => 11,
      ),
      'abvs' => 
      array (
        0 => 12,
      ),
      'blws' => 
      array (
        0 => 13,
      ),
      'psts' => 
      array (
        0 => 14,
      ),
      'haln' => 
      array (
        0 => 15,
      ),
      'locl' => 
      array (
        0 => 16,
      ),
    ),
  ),
  'bng2' => 
  array (
    'DFLT' => 
    array (
      'init' => 
      array (
        0 => 0,
      ),
      'nukt' => 
      array (
        0 => 1,
      ),
      'akhn' => 
      array (
        0 => 2,
      ),
      'rphf' => 
      array (
        0 => 3,
      ),
      'blwf' => 
      array (
        0 => 5,
      ),
      'half' => 
      array (
        0 => 6,
      ),
      'pstf' => 
      array (
        0 => 8,
      ),
      'vatu' => 
      array (
        0 => 9,
      ),
      'pres' => 
      array (
        0 => 10,
        1 => 11,
      ),
      'abvs' => 
      array (
        0 => 12,
      ),
      'blws' => 
      array (
        0 => 13,
      ),
      'psts' => 
      array (
        0 => 14,
      ),
      'haln' => 
      array (
        0 => 15,
      ),
      'locl' => 
      array (
        0 => 16,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 304844,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 304862,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 304920,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 304962,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305000,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305076,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305124,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305614,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305638,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305662,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306128,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 307670,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 307716,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 307774,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 308812,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 308836,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 309342,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 309360,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'beng' => 'DFLT ',
  'bng2' => 'DFLT ',
);
$GPOSFeatures=array (
  'beng' => 
  array (
    'DFLT' => 
    array (
      'blwm' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
  ),
  'bng2' => 
  array (
    'DFLT' => 
    array (
      'blwm' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 309476,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 310204,
    ),
    'MarkFilteringSet' => '',
  ),
);
